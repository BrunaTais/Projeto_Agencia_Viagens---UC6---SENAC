import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {

        Scanner leia = new Scanner(System.in);

        // OBJETO TRANSPORTE
        Transporte transporte = new Transporte();

        System.out.println("Digite o tipo de transporte:");
        transporte.tipo = leia.nextLine();

        System.out.println("Digite o valor do transporte:");
        transporte.valor = leia.nextDouble();

        leia.nextLine();

        // OBJETO HOSPEDAGEM
        Hospedagem hospedagem = new Hospedagem();

        System.out.println("Digite a descricao da hospedagem:");
        hospedagem.descricao = leia.nextLine();

        System.out.println("Digite o valor da diaria:");
        hospedagem.valorDiaria = leia.nextDouble();

        // OBJETO PACOTE
        PacoteViagem pacote = new PacoteViagem();

        pacote.transporte = transporte;
        pacote.hospedagem = hospedagem;

        leia.nextLine();

        System.out.println("Digite o destino:");
        pacote.destino = leia.nextLine();

        System.out.println("Digite a quantidade de dias:");
        pacote.dias = leia.nextInt();

        // VALORES
        System.out.println("Digite a margem de lucro:");
        double margem = leia.nextDouble();

        System.out.println("Digite o valor das taxas:");
        double taxas = leia.nextDouble();

        double totalPacote;

        totalPacote = pacote.calcularTotal(margem, taxas);

        // OBJETO VENDA
        Venda venda = new Venda();

        leia.nextLine();

        System.out.println("Digite o nome do cliente:");
        venda.cliente = leia.nextLine();

        System.out.println("Digite a forma de pagamento:");
        venda.pagamento = leia.nextLine();

        venda.pacote = pacote;

        // COTAÇÃO
        System.out.println("Digite a cotacao do dolar:");
        double cotacao = leia.nextDouble();

        // RESULTADO
        venda.mostrarVenda(totalPacote, cotacao);

    }

}