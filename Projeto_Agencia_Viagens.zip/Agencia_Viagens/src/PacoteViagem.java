public class PacoteViagem {

    Transporte transporte;
    Hospedagem hospedagem;

    String destino;
    int dias;

    public double calcularHospedagem() {

        return hospedagem.valorDiaria * dias;
    }

    public double calcularLucro(double valor,
            double margem) {

        return valor + (valor * margem / 100);
    }

    public double calcularTotal(double margem,
            double taxas) {

        double total;

        total = transporte.valor
                + calcularHospedagem();

        total = calcularLucro(total, margem);

        total = total + taxas;

        return total;
    }

}