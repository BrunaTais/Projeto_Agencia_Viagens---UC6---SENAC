public class Transporte {

    String tipo;
    double valor;

}