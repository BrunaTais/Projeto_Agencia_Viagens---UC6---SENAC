public class Hospedagem {

    String descricao;
    double valorDiaria;

}