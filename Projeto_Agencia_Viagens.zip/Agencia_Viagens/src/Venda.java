public class Venda {

    String cliente;
    String pagamento;

    PacoteViagem pacote;

    public double converterReal(double valorDolar,
            double cotacao) {

        return valorDolar * cotacao;
    }

    public void mostrarVenda(double valorDolar,
            double cotacao) {

        System.out.println("\nDADOS DA VENDA");

        System.out.println("Cliente: "
                + cliente);

        System.out.println("Pagamento: "
                + pagamento);

        System.out.println("Destino: "
                + pacote.destino);

        System.out.println("Valor em dolar: "
                + valorDolar);

        System.out.println("Valor em reais: "
                + converterReal(valorDolar,
                        cotacao));
    }
}